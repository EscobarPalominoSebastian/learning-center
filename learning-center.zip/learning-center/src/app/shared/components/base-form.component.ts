import { Component } from '@angular/core';

@Component({
  selector: 'app-base-form',
  imports: [],
  template: `
    <p>
      base-form works!
    </p>
  `,
  styles: ``
})
export class BaseFormComponent {

}
