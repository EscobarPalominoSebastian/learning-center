
export const environment = {
  // In real lifecycles, this file should not be part of version control
  production: true,
  // Server Base URL for REST API
  serverBaseUrl: 'https://681dfbe0c1c291fa66327f0b.mockapi.io/courses',
  coursesEndpointPath: '/courses',
};

